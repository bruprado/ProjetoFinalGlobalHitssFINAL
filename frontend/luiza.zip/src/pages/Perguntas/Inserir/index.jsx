import axios from 'axios';
import { useState } from 'react';
import { Redirect, Link } from 'react-router-dom';

export default function InserirPergunta() {
    const [state, setState] = useState({
        pergunta: {
            idFormulario: '',
            textoPergunta: '',
            tipo: ''
        }
    });
    const [redirect, setRedirect] = useState(false);

    const handleInputChange = (e) => {
        const name = e.target.name;
        const value = e.target.value;
        setState({
            pergunta: {
                ...state.pergunta, [name]: value
            }
        })
    }

    const handleSubmit = (e) => {
        const req = state.pergunta;
        axios({
            method: 'post',
            url: 'http://localhost:3003/globalhitss/inserirPergunta',
            data: req,
            headers: { "Content-Type": "application/json" }
        }).then(
            data => {
                if (data) {
                    alert("Dados inseridos com sucesso")
                    setRedirect(true);
                }
            }
        ).catch(
            () => { console.log("Não foi possível adicionar os dados") }
        );
        e.preventDefault();
    }

    console.log(state)

    if (redirect) {
        return <Redirect to='/perguntas' />
    } else {
        return (
            <div className="form col-9">
                <h3>Adicionar Pergunta</h3>
                <form onSubmit={handleSubmit}>
                    <div className="form-group mt-3">
                        <label>ID Formulario</label>
                        <input
                            type='text'
                            name='idFormulario'
                            className='form-control'
                            required
                            onChange={handleInputChange}
                        />
                    </div>
                    <div className="form-group mt-3">
                        <label >Pergunta</label>
                        <input
                            type='text'
                            name='textoPergunta'
                            className='form-control'
                            required
                            onChange={handleInputChange}
                        />
                    </div>
                    <div className="form-group mt-3">
                        <label>Tipo da Resposta</label>
                        <select className="form-check-input"
                            type='radio'
                            name='tipo'
                            className='form-control'
                            placeholder="tipo"
                            required
                            onChange={handleInputChange}
                            
                        >
                            <option value="" selected disabled>Selecionar</option>
                            <option value="texto">Texto</option>
                            <option value="radio">Alternativas</option>
                            <option value="bolean">Sim ou Não</option>
                        </select>    
                        
                    </div>
                    <button type='submit' className=" btn mt-3 btn-primary">
                        Adicionar
                    </button>
                </form>
                <button className=" btn  mt-3"><Link to='/perguntas'>Voltar</Link> </button>
            </div>
        )
    }
}
