import React from 'react';
import styled from 'styled-components';
import Burger from './Burger';
import logo from '../../assets/logo.png';


const Nav = styled.nav`
  background-color: #007881;
  height: 100vh;
  width: 220px;
  border-bottom: 2px solid #f1f1f1;
  padding: 10px;
  //flex-flow: row nowrap;
  //justify-content: space-between;
  color: #f1f1f1;

  .logoName {
    padding: 10px;
    width: 50%;
  }
  .simbolo{
    padding: 10px;
    width: 30vh;
  }
  @media (max-width: 768px) {
    background-color: white;
  }
`

const Navbar = () => {
  return (
    <Nav>
      <div className="logoName">
        <img src={logo} className="simbolo"/>
      </div>
      
      <Burger />
    </Nav>
  )
}

export default Navbar