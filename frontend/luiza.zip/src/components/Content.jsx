import React from 'react';
import {Switch, Route, Redirect} from 'react-router-dom';
import Home from './Home';
import UsuariosRoute from '../routes/UsuariosRoutes';
import TimesRoute from '../routes/TimesRoutes';
import FormulariosRoute from '../routes/FormulariosRoutes';
import PerguntasRoute from '../routes/PerguntasRoutes';
import RespostasRoute from '../routes/RespostasRoutes';


function Content(){
    return(
        
        <div className="flex-shrink-0">
            <div className="container">
                
                <Switch>
                <Route exact path='/' component={Home} />
                </Switch>
                <UsuariosRoute/>    
                <TimesRoute/> 
                <FormulariosRoute/>
                <PerguntasRoute/>
                <RespostasRoute/>
            </div>  
        </div>
       
        
    )
}

export default Content;